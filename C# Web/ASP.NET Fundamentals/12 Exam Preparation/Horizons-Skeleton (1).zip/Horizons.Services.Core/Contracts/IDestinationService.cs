﻿namespace Horizons.Services.Core.Contracts
{
    public interface IDestinationService
    {
    }
}
