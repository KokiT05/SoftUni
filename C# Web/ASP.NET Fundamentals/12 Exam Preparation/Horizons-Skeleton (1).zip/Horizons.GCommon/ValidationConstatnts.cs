﻿namespace Horizons.GCommon
{
    public static class ValidationConstatnts
    {
    }
}
