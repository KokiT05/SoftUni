﻿using RecipeSharingPlatform.Services.Core.Contracts;

namespace RecipeSharingPlatform.Services.Core
{
    public class RecipeService : IRecipeService
    {
    }
}
