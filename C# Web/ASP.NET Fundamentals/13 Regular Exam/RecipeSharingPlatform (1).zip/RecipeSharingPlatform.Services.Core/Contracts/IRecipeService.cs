﻿namespace RecipeSharingPlatform.Services.Core.Contracts
{
    public interface IRecipeService
    {       

    }
}
