﻿namespace RecipeSharingPlatform.GCommon
{
    public class ValidationConstants
    {
    }
}
