﻿namespace Bakery.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
